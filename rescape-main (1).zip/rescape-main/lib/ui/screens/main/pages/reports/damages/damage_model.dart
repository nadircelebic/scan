class DamageModel {
  DateTime time;
  String from, image, message, key;

  DamageModel({
    this.time,
    this.from,
    this.image,
    this.message,
    this.key,
  });
}
