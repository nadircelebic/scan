class VehicleModel {
  String model, plates;
  int category;

  VehicleModel({this.model, this.plates, this.category});
}
