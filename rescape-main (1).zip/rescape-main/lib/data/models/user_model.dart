class UserModel {
  String name, userType;

  UserModel(this.name, this.userType);
}
