class LocationModel {
  String id, companyName, number, address, city;

  LocationModel({
    this.id,
    this.companyName,
    this.number,
    this.address,
    this.city,
  });
}
