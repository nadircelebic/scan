package com.example.rescape

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
